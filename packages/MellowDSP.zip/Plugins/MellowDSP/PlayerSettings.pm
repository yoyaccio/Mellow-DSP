package Plugins::MellowDSP::PlayerSettings;

use strict;
use warnings;
use base qw(Slim::Web::Settings);

my $prefs = preferences('plugin.mellowdsp');

sub new {
    my $class = shift;
    return bless {}, $class;
}

sub name {
    return 'PLUGIN_MELLOWDSP';
}

sub page {
    return 'plugins/MellowDSP/settings/player.html';
}

sub prefs {
    return ($prefs, qw(enabled upsample_rate));
}

sub handler {
    my ($class, $client, $params) = @_;

    my $cprefs = $prefs->client($client);

    if ($params->{saveSettings}) {
        $cprefs->set('enabled', $params->{pref_enabled} ? 1 : 0);
        $cprefs->set('upsample_rate', $params->{pref_upsample_rate} || '44100');
    }

    $params->{pref_enabled}       = $cprefs->get('enabled')       || 0;
    $params->{pref_upsample_rate} = $cprefs->get('upsample_rate') || '44100';

    return $class->SUPER::handler($client, $params);
}

1;
