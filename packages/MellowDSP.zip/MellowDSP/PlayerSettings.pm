package Plugins::MellowDSP::PlayerSettings;

use strict;
use warnings;

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $log   = logger('plugin.mellowdsp');
my $prefs = preferences('plugin.mellowdsp');

sub new { bless {}, shift }

sub handler {
    my ($class, $client, $params) = @_;
    my $cprefs = $prefs->client($client);

    if ($params->{saveSettings}) {
        $cprefs->set('enabled', $params->{enabled} ? 1 : 0);
        $cprefs->set('upsample_rate', $params->{upsample_rate} || '44100');
    }

    $params->{enabled}       = $cprefs->get('enabled')       || 0;
    $params->{upsample_rate} = $cprefs->get('upsample_rate') || '44100';

    return Slim::Web::HTTP::filltemplatefile('plugins/MellowDSP/settings/player.html', $params);
}

1;
