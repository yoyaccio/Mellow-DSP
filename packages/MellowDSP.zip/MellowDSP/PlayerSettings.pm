package Plugins::MellowDSP::PlayerSettings;
use strict;
use warnings;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.mellowdsp');

sub handler {
    my ($class, $client, $params) = @_;
    my $cp = $prefs->client($client);

    if ($params->{saveSettings}) {
        $cp->set('enabled', $params->{enabled} ? 1 : 0);
        $cp->set('fir_file_left', $params->{fir_file_left} || '');
        $cp->set('fir_file_right', $params->{fir_file_right} || '');
    }

    $params->{enabled}        = $cp->get('enabled') || 0;
    $params->{fir_file_left}  = $cp->get('fir_file_left') || '';
    $params->{fir_file_right} = $cp->get('fir_file_right') || '';

    return $class->SUPER::handler($client, $params);
}

1;
