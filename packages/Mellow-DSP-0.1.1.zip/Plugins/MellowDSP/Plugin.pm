package Plugins::MellowDSP::Plugin;

use strict;
use warnings;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Web::Settings;

my $log   = logger('plugin.mellowdsp');
my $prefs = preferences('plugin.mellowdsp');

sub initPlugin {
    Slim::Web::Settings->registerSettingsPage({
        id     => 'MellowDSP',
        module => 'Plugins::MellowDSP::PlayerSettings',
        class  => 'Plugins::MellowDSP::PlayerSettings',
        func   => 'handler',
        player => 1,  # importante: pagina per-player
    });

    $log->info("Mellow-DSP plugin initialized");
    return 1;
}

1;
