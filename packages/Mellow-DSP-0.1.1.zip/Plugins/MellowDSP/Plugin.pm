package Plugins::MellowDSP::Plugin;
use strict; use warnings;
use base qw(Slim::Plugin::Base);
use Slim::Utils::Log;

my $log = Slim::Utils::Log->addLogCategory({
  category=>'plugin.mellowdsp', defaultLevel=>'INFO', description=>'MellowDSP',
});

sub initPlugin {
  my $class = shift;
  if ( main::WEBUI ) {
    require Plugins::MellowDSP::PlayerSettings;
    Plugins::MellowDSP::PlayerSettings->new;
  }
  return $class->SUPER::initPlugin(@_);
}
1;
