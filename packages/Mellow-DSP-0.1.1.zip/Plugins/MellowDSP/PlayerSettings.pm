package Plugins::MellowDSP::PlayerSettings;
use strict; use warnings;
use base qw(Slim::Web::Settings);
use Slim::Utils::Prefs; use Slim::Utils::Log;

my $prefs = preferences('plugin.mellowdsp'); my $log = logger('plugin.mellowdsp');

sub name { 'PLUGIN_MELLOWDSP' }
sub page { 'plugins/MellowDSP/settings/player.html' }
sub needsClient { 1 }
sub prefs { my ($c,$client)=@_; return ($prefs->client($client), qw(enabled upsample_rate)); }

sub handler {
  my ($class,$client,$p,$cb,@a)=@_;
  my ($cp)= $class->prefs($client);
  if ($p->{saveSettings}) {
    $cp->set('enabled', $p->{pref_enabled} ? 1 : 0);
    $cp->set('upsample_rate', $p->{pref_upsample_rate} || '44100');
  }
  $p->{pref_enabled}       = $cp->get('enabled')       || 0;
  $p->{pref_upsample_rate} = $cp->get('upsample_rate') || '44100';
  return $class->SUPER::handler($client,$p,$cb,@a);
}
1;
