package Plugins::MellowDSP::Plugin;
use strict;
use warnings;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Web::Pages;
use Slim::Player::Player;

my $log   = logger('plugin.mellowdsp');
my $prefs = preferences('plugin.mellowdsp');

sub initPlugin {
    Slim::Player::Player::addPlayerSettingsPage(
        'PLUGIN_MELLOWDSP',
        \&Plugins::MellowDSP::PlayerSettings::handler
    );
    return 1;
}

1;
