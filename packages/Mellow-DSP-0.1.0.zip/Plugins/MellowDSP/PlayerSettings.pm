package Plugins::MellowDSP::PlayerSettings;

use strict;
use warnings;
use base qw(Slim::Web::Settings);   # <--- importante!
use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.mellowdsp');
my $log   = logger('plugin.mellowdsp');

sub name {
    return 'PLUGIN_MELLOWDSP';
}

sub page {
    return 'plugins/MellowDSP/settings/player.html';
}

sub prefs {
    my ($class, $client) = @_;
    return ($prefs->client($client), qw(enabled upsample_rate));
}

sub handler {
    my ($class, $client, $paramRef, $callback, @args) = @_;

    my ($cprefs) = $class->prefs($client);

    if ($paramRef->{saveSettings}) {
        $cprefs->set('enabled', $paramRef->{pref_enabled} ? 1 : 0);
        $cprefs->set('upsample_rate', $paramRef->{pref_upsample_rate} || '44100');
    }

    $paramRef->{pref_enabled}       = $cprefs->get('enabled') || 0;
    $paramRef->{pref_upsample_rate} = $cprefs->get('upsample_rate') || '44100';

    return $class->SUPER::handler($client, $paramRef, $callback, @args);
}

1;
