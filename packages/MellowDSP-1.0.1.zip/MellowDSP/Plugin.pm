package Plugins::MellowDSP::Plugin;
use base qw(Slim::Plugin::Base);
sub getDisplayName { return 'MellowDSP'; }
1;
