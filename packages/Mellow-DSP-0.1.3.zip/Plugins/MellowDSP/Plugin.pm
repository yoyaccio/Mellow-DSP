package Plugins::MellowDSP::Plugin;
use strict;
use warnings;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Web::Settings;

my $log   = logger('plugin.mellowdsp');
my $prefs = preferences('plugin.mellowdsp');

sub initPlugin {
    Slim::Web::Settings->addPlayerSettingsHandler(
        'MellowDSP',
        \&Plugins::MellowDSP::PlayerSettings::handler,
    );
    return 1;
}

1;
