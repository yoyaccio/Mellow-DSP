package Plugins::MellowDSP::Plugin;

use strict;
use warnings;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Web::Settings;

my $log   = logger('plugin.mellowdsp');
my $prefs = preferences('plugin.mellowdsp');

sub initPlugin {
    Slim::Web::Settings->registerSettingsPage({
        id     => 'MellowDSP',
        module => 'Plugins::MellowDSP::PlayerSettings',
        class  => 'Plugins::MellowDSP::PlayerSettings',
        func   => 'handler',
        player => 1,  # fondamentale per apparire sotto Player
    });

    $log->info("Mellow-DSP plugin registered successfully");
    return 1;
}

1;
